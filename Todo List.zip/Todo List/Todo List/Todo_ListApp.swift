//
//  Todo_ListApp.swift
//  Todo List
//
//  Created by Casey Traina on 9/24/21.
//

import SwiftUI

@main
struct Todo_ListApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
